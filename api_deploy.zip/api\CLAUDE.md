# api — CLAUDE.md

## What it does

FastAPI server that receives key event batches from keyspy clients and stores them in PostgreSQL. Will eventually run AI analysis on the stored data and serve summaries to the admin dashboard.

## How to Run

From the project root:
```bash
uvicorn api.src.server:app --reload
```

Runs on `http://127.0.0.1:8000`. Interactive docs at `http://127.0.0.1:8000/docs`.

## Key Files

- `src/server.py` — the entire server
- `src/.env` — DB credentials (not committed to git)
- `src/keyspy.postman_collection.json` — Postman collection for manual testing

## Environment Variables (.env)

```
DB_HOST=localhost
DB_NAME=yangardDB
DB_USER=postgres
DB_PASSWORD=...
```

## Current Endpoints

- `POST /api/key_events` — receives a batch of key events from keyspy, inserts into DB
- `POST /api/keepalive` — ping from keyspy to confirm connectivity

## Database

PostgreSQL database `yangardDB` with two tables:

**`key_events`**
- `user_uuid VARCHAR(36)` — identifies which user sent the batch
- `key_events JSONB` — array of key event objects `{timestamp, key, app}`

**`users`**
- `uuid VARCHAR(36)`
- `name VARCHAR(255)`
- `email VARCHAR(255)`
- `password VARCHAR(255)`

## Key Decisions

- Key events stored as JSONB array — one row per batch, not one row per keystroke
- `user_uuid` comes from the client request, not generated server-side
- DB credentials loaded from `.env` via `python-dotenv`
- pydantic models (`KeyEvent`, `KeyEventBatch`) validate incoming requests automatically

## Future

- GET endpoint to fetch summaries per user and date for the admin dashboard
- AI analysis of stored key events to generate summaries
- User authentication (registration, login, tokens)
- HTTPS when deployed to a real server
